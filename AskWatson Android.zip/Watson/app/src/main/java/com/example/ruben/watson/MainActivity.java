package com.example.ruben.watson;

import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;


import org.json.JSONObject;

import java.util.HashMap;

public class MainActivity extends AppCompatActivity {

    private TextView respuesta;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        respuesta = (TextView)findViewById(R.id.respuesta);
    }

    public void post(View view){
        EditText text = (EditText)findViewById(R.id.editText);

        respuesta.setText("Pensando...");
        PostAsyncTask asyncTask = new PostAsyncTask(this,text.getText().toString(),"Cargando",false);
        try {
            String res = asyncTask.execute("https://dal09-gateway.watsonplatform.net/instance/582/deepqa/v1/question").get();
            JSONObject json = new JSONObject(res);
            String t = json.getJSONObject("question").getJSONArray("answers").getJSONObject(0).getString("text");
            if(!t.equals("${noAnswer}")) {
                String[] sep = t.split("-");
                String r = "";
                for(int i=1;i<sep.length;i++){
                    if(r.equals("")){
                        r = sep[i];
                    }else{
                        r+= " " + sep[i];
                    }
                }
                String ev = json.getJSONObject("question").getJSONArray("evidencelist").getJSONObject(0).getString("text");
                respuesta.setText("Answer: " + r + "\n" + "Additional Info: " + ev);
            }else{
                respuesta.setText("No answer available");
            }
        }catch(Exception e){
            respuesta.setText("No answer available");
        }

        /*Esto era para Mobile Access Client
        try {

            BMSClient.getInstance().initialize(this, "https://bluemixwatson2999.mybluemix.net", "0a3fc60c-3eea-42fe-a5a0-2e9325785ba5");
            new Request(BMSClient.getInstance().getBluemixAppRoute() + "/ruta", Request.GET).send(this,this);

        }catch(Exception e){
            e.printStackTrace();
        }*/
    }


}
